﻿namespace pizza
{
    partial class Rendeles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bezár = new System.Windows.Forms.Button();
            this.töröl = new System.Windows.Forms.Button();
            this.Menüválaszték = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Db5 = new System.Windows.Forms.TextBox();
            this.Db4 = new System.Windows.Forms.TextBox();
            this.Db3 = new System.Windows.Forms.TextBox();
            this.Db2 = new System.Windows.Forms.TextBox();
            this.Db1 = new System.Windows.Forms.TextBox();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.Torino = new System.Windows.Forms.CheckBox();
            this.Negysajtos = new System.Windows.Forms.CheckBox();
            this.Vesuvio = new System.Windows.Forms.CheckBox();
            this.Magyaros = new System.Windows.Forms.CheckBox();
            this.Vegetariánus = new System.Windows.Forms.CheckBox();
            this.szamolbt = new System.Windows.Forms.Button();
            this.összeglb = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bezár
            // 
            this.bezár.Location = new System.Drawing.Point(659, 415);
            this.bezár.Name = "bezár";
            this.bezár.Size = new System.Drawing.Size(75, 23);
            this.bezár.TabIndex = 15;
            this.bezár.Text = "Bezár";
            this.bezár.UseVisualStyleBackColor = true;
            this.bezár.Click += new System.EventHandler(this.bezár_Click);
            // 
            // töröl
            // 
            this.töröl.Location = new System.Drawing.Point(130, 415);
            this.töröl.Name = "töröl";
            this.töröl.Size = new System.Drawing.Size(75, 23);
            this.töröl.TabIndex = 16;
            this.töröl.Text = "Töröl";
            this.töröl.UseVisualStyleBackColor = true;
            this.töröl.Click += new System.EventHandler(this.töröl_Click);
            // 
            // Menüválaszték
            // 
            this.Menüválaszték.AutoSize = true;
            this.Menüválaszték.Font = new System.Drawing.Font("Rockwell", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Menüválaszték.Location = new System.Drawing.Point(321, 9);
            this.Menüválaszték.Name = "Menüválaszték";
            this.Menüválaszték.Size = new System.Drawing.Size(164, 26);
            this.Menüválaszték.TabIndex = 22;
            this.Menüválaszték.Text = "Menüválaszték";
            this.Menüválaszték.Click += new System.EventHandler(this.Menüválaszték_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Db5);
            this.groupBox1.Controls.Add(this.Db4);
            this.groupBox1.Controls.Add(this.Db3);
            this.groupBox1.Controls.Add(this.Db2);
            this.groupBox1.Controls.Add(this.Db1);
            this.groupBox1.Controls.Add(this.radioButton10);
            this.groupBox1.Controls.Add(this.radioButton9);
            this.groupBox1.Controls.Add(this.radioButton8);
            this.groupBox1.Controls.Add(this.radioButton7);
            this.groupBox1.Controls.Add(this.radioButton6);
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.Torino);
            this.groupBox1.Controls.Add(this.Negysajtos);
            this.groupBox1.Controls.Add(this.Vesuvio);
            this.groupBox1.Controls.Add(this.Magyaros);
            this.groupBox1.Controls.Add(this.Vegetariánus);
            this.groupBox1.Location = new System.Drawing.Point(57, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(714, 313);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "választék";
            this.groupBox1.Visible = false;
            // 
            // Db5
            // 
            this.Db5.Location = new System.Drawing.Point(577, 241);
            this.Db5.Name = "Db5";
            this.Db5.Size = new System.Drawing.Size(100, 20);
            this.Db5.TabIndex = 41;
            // 
            // Db4
            // 
            this.Db4.Location = new System.Drawing.Point(577, 192);
            this.Db4.Name = "Db4";
            this.Db4.Size = new System.Drawing.Size(100, 20);
            this.Db4.TabIndex = 40;
            // 
            // Db3
            // 
            this.Db3.Location = new System.Drawing.Point(577, 140);
            this.Db3.Name = "Db3";
            this.Db3.Size = new System.Drawing.Size(100, 20);
            this.Db3.TabIndex = 39;
            // 
            // Db2
            // 
            this.Db2.Location = new System.Drawing.Point(577, 96);
            this.Db2.Name = "Db2";
            this.Db2.Size = new System.Drawing.Size(100, 20);
            this.Db2.TabIndex = 38;
            // 
            // Db1
            // 
            this.Db1.Location = new System.Drawing.Point(577, 51);
            this.Db1.Name = "Db1";
            this.Db1.Size = new System.Drawing.Size(100, 20);
            this.Db1.TabIndex = 37;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(435, 240);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(52, 17);
            this.radioButton10.TabIndex = 36;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "980 ft";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(219, 241);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(52, 17);
            this.radioButton9.TabIndex = 35;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "980 ft";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(435, 192);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(58, 17);
            this.radioButton8.TabIndex = 34;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "1090 ft";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(219, 192);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(58, 17);
            this.radioButton7.TabIndex = 33;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "1090 ft";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(435, 140);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(52, 17);
            this.radioButton6.TabIndex = 32;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "990 ft";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(219, 140);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(52, 17);
            this.radioButton5.TabIndex = 31;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "990 ft";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(435, 96);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(52, 17);
            this.radioButton4.TabIndex = 30;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "950 ft";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(219, 96);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(52, 17);
            this.radioButton3.TabIndex = 29;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "950 ft";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(435, 51);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(52, 17);
            this.radioButton2.TabIndex = 28;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "890 ft";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(219, 51);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(52, 17);
            this.radioButton1.TabIndex = 27;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "890 ft";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // Torino
            // 
            this.Torino.AutoSize = true;
            this.Torino.Location = new System.Drawing.Point(38, 241);
            this.Torino.Name = "Torino";
            this.Torino.Size = new System.Drawing.Size(56, 17);
            this.Torino.TabIndex = 26;
            this.Torino.Text = "Torino";
            this.Torino.UseVisualStyleBackColor = true;
            // 
            // Negysajtos
            // 
            this.Negysajtos.AutoSize = true;
            this.Negysajtos.Location = new System.Drawing.Point(38, 192);
            this.Negysajtos.Name = "Negysajtos";
            this.Negysajtos.Size = new System.Drawing.Size(81, 17);
            this.Negysajtos.TabIndex = 25;
            this.Negysajtos.Text = "Négy sajtos";
            this.Negysajtos.UseVisualStyleBackColor = true;
            // 
            // Vesuvio
            // 
            this.Vesuvio.AutoSize = true;
            this.Vesuvio.Location = new System.Drawing.Point(38, 140);
            this.Vesuvio.Name = "Vesuvio";
            this.Vesuvio.Size = new System.Drawing.Size(64, 17);
            this.Vesuvio.TabIndex = 24;
            this.Vesuvio.Text = "Vesuvio";
            this.Vesuvio.UseVisualStyleBackColor = true;
            // 
            // Magyaros
            // 
            this.Magyaros.AutoSize = true;
            this.Magyaros.Location = new System.Drawing.Point(38, 96);
            this.Magyaros.Name = "Magyaros";
            this.Magyaros.Size = new System.Drawing.Size(72, 17);
            this.Magyaros.TabIndex = 23;
            this.Magyaros.Text = "Magyaros";
            this.Magyaros.UseVisualStyleBackColor = true;
            // 
            // Vegetariánus
            // 
            this.Vegetariánus.AutoSize = true;
            this.Vegetariánus.Location = new System.Drawing.Point(38, 51);
            this.Vegetariánus.Name = "Vegetariánus";
            this.Vegetariánus.Size = new System.Drawing.Size(88, 17);
            this.Vegetariánus.TabIndex = 22;
            this.Vegetariánus.Text = "Vegetariánus";
            this.Vegetariánus.UseVisualStyleBackColor = true;
            // 
            // szamolbt
            // 
            this.szamolbt.Location = new System.Drawing.Point(130, 385);
            this.szamolbt.Name = "szamolbt";
            this.szamolbt.Size = new System.Drawing.Size(75, 23);
            this.szamolbt.TabIndex = 24;
            this.szamolbt.Text = "Számol";
            this.szamolbt.UseVisualStyleBackColor = true;
            this.szamolbt.Click += new System.EventHandler(this.szamolbt_Click);
            // 
            // összeglb
            // 
            this.összeglb.AutoSize = true;
            this.összeglb.Font = new System.Drawing.Font("Rockwell", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.összeglb.Location = new System.Drawing.Point(321, 408);
            this.összeglb.Name = "összeglb";
            this.összeglb.Size = new System.Drawing.Size(231, 30);
            this.összeglb.TabIndex = 25;
            this.összeglb.Text = "Végösszeg:            ft";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(57, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 26;
            this.button1.Text = "Kezdjük";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Rendeles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.összeglb);
            this.Controls.Add(this.szamolbt);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Menüválaszték);
            this.Controls.Add(this.töröl);
            this.Controls.Add(this.bezár);
            this.Name = "Rendeles";
            this.Text = "Rendeles";
            this.Load += new System.EventHandler(this.Rendeles_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bezár;
        private System.Windows.Forms.Button töröl;
        private System.Windows.Forms.Label Menüválaszték;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Db5;
        private System.Windows.Forms.TextBox Db4;
        private System.Windows.Forms.TextBox Db3;
        private System.Windows.Forms.TextBox Db2;
        private System.Windows.Forms.TextBox Db1;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.CheckBox Torino;
        private System.Windows.Forms.CheckBox Negysajtos;
        private System.Windows.Forms.CheckBox Vesuvio;
        private System.Windows.Forms.CheckBox Magyaros;
        private System.Windows.Forms.CheckBox Vegetariánus;
        private System.Windows.Forms.Button szamolbt;
        private System.Windows.Forms.Label összeglb;
        private System.Windows.Forms.Button button1;
    }
}