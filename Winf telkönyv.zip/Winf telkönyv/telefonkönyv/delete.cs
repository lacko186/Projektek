﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection.Emit;

namespace telefonkönyv
{
    public partial class delete : Form
    {
        class TeleFo
        {
            public string név;
            public string tel;
            public string mail;
            public string address;

            public TeleFo(string sor)
            {
                string[] r = sor.Split(',');
                this.név = r[0];
                this.tel = r[1];
                this.mail = r[2];
                this.address = r[3];
            }
        }
        public delete()
        {

            InitializeComponent();

        }


        private void Vissza_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void keres_Click(object sender, EventArgs e)
        {
            List<TeleFo> list = new List<TeleFo>();
            StreamReader SR = new StreamReader("D:\\kontaktok.txt");
            while (!SR.EndOfStream)
            {
                string sor = SR.ReadLine();
                TeleFo teleF = new TeleFo(sor);
                list.Add(teleF);
            }
            SR.Close();
            string keres = textBox1.Text;
            for (int i = 0; i < list.Count(); i++)
            {
                if (list[i].név == keres)
                {
                    list.Remove(list[i]);
                }
                else
                {
                  label2.Text = "Nem található ilyen név a konntaktok között";
                }
            }

        }
    }
    }

