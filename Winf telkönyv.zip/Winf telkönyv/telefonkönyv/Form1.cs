﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace telefonkönyv
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            List<string> list = new List<string>();
        }

        private void bevitel_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "1")
            {

                Form1 form1 = new Form1();
                addnew addnew = new addnew();
                addnew.Show();

                Visible = false;
            }if (textBox1.Text == "2")
            {
                Form1 form1 = new Form1();
                display display = new display();
                display.Show();

                Visible = false;
            }if (textBox1.Text == "4")
            {
                Form1 form1 = new Form1();
                modify modify = new modify();
                modify.Show();

                Visible = false;
            }if (textBox1.Text == "5")
            {
                Form1 form1 = new Form1();
                search search= new search();
                search.Show();

                Visible = false;
            }if (textBox1.Text == "6")
            {
                Form1 form1 = new Form1();
                delete delete = new delete();
                delete.Show();

                Visible = false;
            }if (textBox1.Text == "3")
            {
                Application.Exit();
            }

        }
    }
}
