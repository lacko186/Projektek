﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace telefonkönyv
{
    public partial class addnew : Form
    {
        public addnew()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void addnew_Load(object sender, EventArgs e)
        {

        }

        private void Vissza_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            Visible = false;
        }

        private void hozzáad_Click(object sender, EventArgs e)
        {

            StreamWriter sw = new StreamWriter("d:\\kontaktok.txt");
              

                    if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
                    {


                        string a = $"{textBox1.Text}, {textBox2.Text}, {textBox3.Text}, {textBox4.Text}";
                    sw.WriteLine(a);
                    }
                    else
                    {
                        Console.WriteLine("Nem sikerült hozzáadni");
                    }
                    sw.Close();
                    
                }
            }
        }
    

