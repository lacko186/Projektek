﻿namespace telefonkönyv
{
    partial class display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.összes = new System.Windows.Forms.Label();
            this.Vissza = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // összes
            // 
            this.összes.AutoSize = true;
            this.összes.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.összes.Location = new System.Drawing.Point(45, 102);
            this.összes.Name = "összes";
            this.összes.Size = new System.Drawing.Size(63, 24);
            this.összes.TabIndex = 0;
            this.összes.Text = "összes";
            // 
            // Vissza
            // 
            this.Vissza.BackColor = System.Drawing.SystemColors.Desktop;
            this.Vissza.Location = new System.Drawing.Point(291, 385);
            this.Vissza.Name = "Vissza";
            this.Vissza.Size = new System.Drawing.Size(157, 23);
            this.Vissza.TabIndex = 6;
            this.Vissza.Text = "Vissza";
            this.Vissza.UseVisualStyleBackColor = false;
            this.Vissza.Click += new System.EventHandler(this.Vissza_Click);
            // 
            // display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Vissza);
            this.Controls.Add(this.összes);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "display";
            this.Text = "display";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label összes;
        private System.Windows.Forms.Button Vissza;
    }
}