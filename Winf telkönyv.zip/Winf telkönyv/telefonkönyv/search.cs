﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace telefonkönyv
{
    
    public partial class search : Form
    {
        class TeleF
        {
            public string név;
            public string tel;
            public string mail;
            public string address;

            public TeleF(string sor)
            {
                string[] r = sor.Split(',');
                this.név = r[0];
                this.tel = r[1];
                this.mail = r[2];
                this.address = r[3];
            }
        }
        public search()
        {
            InitializeComponent();
        }

        private void Vissza_Click(object sender, EventArgs e)
        {

            Form1 form1 = new Form1();
           
            form1.Show();
            Visible = false;
        }

        private void keres_Click(object sender, EventArgs e)
        {
            List<TeleF> list = new List<TeleF>();
            StreamReader SR = new StreamReader("D:\\kontaktok.txt");
            while (!SR.EndOfStream)
            {
                string sor = SR.ReadLine();
                TeleF teleF = new TeleF(sor);
                list.Add(teleF);
            }SR.Close();
            string keres = textBox1.Text; 
            for (int i = 0; i < list.Count(); i++)
            {
                if (list[i].név == keres)
                {
                    label2.Text = $"neve: {list[i].név},   tel: {list[i].tel}    mail: {list[i].mail},    cím: {list[i].address}";
                }
                else
                {
                    label2.Text= "Nem található ilyen név a konntaktok között";
                }
            }
    
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
