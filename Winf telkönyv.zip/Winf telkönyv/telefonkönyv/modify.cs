﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace telefonkönyv
{
    public partial class modify : Form
    {
        public modify()
        {
            InitializeComponent();
        
        }
        class Telefon
            {

            public string név;
            public string tel;
            public string mail;
            public string address;

            public Telefon(string sor)
            {
                string[] r = sor.Split(',');
                this.név = r[0];
                this.tel = r[1];
                this.mail = r[2];
                this.address = r[3];
            }
        }
        private void Vissza_Click(object sender, EventArgs e)
        {

            Form1 form1 = new Form1();
            form1.Show();
            
        }
        List<Telefon> list = new List<Telefon>();

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("d:\\kontaktok.txt");
            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                Telefon telefon = new Telefon(sor);
                list.Add(telefon);
            }sr.Close();
            for (int i = 0; i < list.Count(); i++)
            {
                if (textBox2.Text == list[i].név)
                {
                    list[i].tel.Remove(i);
                    list[i].mail.Remove(i);
                    list[i].address.Remove(i);

                }
                list[i].név = textBox2.Text;
                list[i].tel = textBox3.Text;
                list[i].mail = textBox4.Text;
                list[i].address = textBox5.Text;
            }

        }

        private void keres_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < list.Count(); i++)
            {
                if (textBox2.Text == list[i].név)
                {
                   label5.Text = $"megtalálva {list[i].név} nevű felhasználó";
                }
                else
                {
                    label5.Text = "Nincs ilyen konntakt";
                }
            }
           
        }
    }
}
