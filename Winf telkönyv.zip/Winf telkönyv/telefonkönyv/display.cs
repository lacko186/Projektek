﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace telefonkönyv
{
    public partial class display : Form
    {
        class Tele
        {
            public string nev;
            public string tel;
            public string email;
            public string address;

            public Tele(string sor)
            {
                string[] r = sor.Split(',');
                this.nev = r[0];
                this.tel = r[1];
                this.email = r[2];
                this.address = r[3];
            }
        }
            public display()
        {
            InitializeComponent();
            List<Tele> list = new List<Tele>();
            StreamReader sr = new StreamReader("d:\\kontaktok.txt");
            while (!sr.EndOfStream)
            {

                string sor = sr.ReadLine();
                Tele tele = new Tele(sor);
                list.Add(tele);

            }sr.Close();
            for (int i = 0; i < list.Count(); i++)
            {
                bool a = true;

                if (a == true)
                {

                    összes.Text =$"név: {list[i].nev} tel: {list[i].tel} email:{list[i].email} cím:{list[i].email}";
                }
            }
        }

        private void Vissza_Click(object sender, EventArgs e)
        {

            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
